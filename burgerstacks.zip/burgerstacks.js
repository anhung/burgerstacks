window.onload = init;
document.onkeypress = keyHit;
document.onkeydown = keyHit;

var playerLeft; // int representing the left of the two player columns
var column0;    // array; left-most column's cells
var column1;    // array; middle left column's cells
var column2;    // array; middle right column's cells
var column3;    // array; right-most column's cells
var spawns;     // array; spawn row's cells
var ingredients;

/*
    Set up function to initialize variables.
    Then calls the game loop function.
*/
function init() {
    var idName;
    playerLeft = 1;
    ingredients = new Array(
        "Top bun",
        "Cheese",
        "Lettuce",
        "Onion",
        "Tomato",
        "Patty",
        "Bottom bun");
    column0 = new Array(9);
    column1 = new Array(9);
    column2 = new Array(9);
    column3 = new Array(9);
    spawns = new Array(4);
    // helper function
    function initSection(section, offset, cellType) {
        for (var i = 0; i < section.length; i++) {
            idName = cellType + (offset + i);
            section[i] = document.getElementById(idName);
            if (cellType === "spawn") {
                section[i].innerHTML = getRandomIngredient();
            }
        }
    }      
    initSection(column0, 0, "grid");
    initSection(column1, 9, "grid");
    initSection(column2, 18, "grid");
    initSection(column3, 27, "grid");
    initSection(spawns, 0, "spawn");
    game();
} 

/*
    Main game loop.
*/
function game() {
    var gameOver = false;
    if (gameOver) {
        gameOver();
    }
    else {
        
    }
} 

/*
    Code for when the game is over.
    Reset grid and new game?
*/
function gameOver() {
    
}

/*
    Generate a random ingredient.
*/
function getRandomIngredient() {
    return ingredients[Math.ceil(Math.random() * 6)];
}

function keyHit(evt) {
    var thisKey;
    var key_left = 37;
    var key_right = 39;
    var key_a = 97;
    var key_s = 115;
    if (evt) {
        thisKey = evt.charCode;
    }
    else {
        thisKey = window.event.keyCode;
    }
    
    if (thisKey === key_a) {
        column0[0].innerHTML = "a";
    }
    else if (thisKey === key_s) {
        column0[0].innerHTML = "s";
    }
        
}

/*** BRAINSTORM SECTION 
Top bun     1
Cheese      2
Lettuce     3
Onion       4
Tomato      5
Patty       6
Bottom bun  7

Total Items: 7

Power ups:
Nibble: Remove top ingredient from selected row
Bite: Remove top ingredient from each column.
Nom Nom Nom: Clear a entire column
***/
